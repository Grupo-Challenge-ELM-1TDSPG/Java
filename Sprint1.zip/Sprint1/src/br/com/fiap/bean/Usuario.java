package br.com.fiap.bean;

/**
 * Classe para criar objetos do tipo <strong>Usuario</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Usuario {
    //atributos
    private String cpf;
    private String nome;

    //construtores
    public Usuario() {}
    public Usuario(String cpf, String nome) {
        setCpf(cpf);
        setNome(nome);
    }

    //getters / setters

    //cpf
    public String getCpf() {
        return cpf;
    }
    /**
     * O setter "setCpf", recebe uma string por parametro em formato de cpf, que pode ou não ter pontos ou hifens. Depois formata tirando os pontos e hifens e analisando se a string tem 11 caracteres, retorna normalmente, caso contrário, faz o tratamento de erro.
     * @author Lucas Barros Gouveia
     * @param cpf é o cpf passado por parametro.
     */
    public void setCpf(String cpf) {
        try {
            if (cpf.matches("^(\\d{11}|\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2})$")) {
                this.cpf = cpf.replace(".", "").replace("-", "");
            } else {
                throw new Exception("cpf inválido! Deve possuir 11 caracteres.");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //nome
    public String getNome() {
        return nome;
    }
    /**
     * O setter "setNome", recebe uma string por parametro que não aceita caracteres especiais (com excessão do hifen) ou números, mas aceita acentos e letras.
     * @author Lucas Barros Gouveia
     * @param nome é o nome passado por parametro.
     */
    public void setNome(String nome) {
        try {
            if (nome.matches("^\\p{L}[\\p{L} \\-']*$")) {
                this.nome = nome;
            } else {
                throw new Exception("Nome inválido! Não use caracteres especiais ou números.");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //metodos
    /**
     * O metodo registrar recebe por parametro as Strings "cpf" e "nome" e chama os seus respectivos setters, para fazer o tratamento caso ocorra um erro.
     * @author Lucas Barros Gouveia.
     * @param cpf é o cpf passado por parametro.
     * @param nome é o nome passado por parametro.
     */
    public void registrar(String cpf, String nome) {
        setCpf(cpf);
        setNome(nome);
    }
    /**
     * O metodo logar recebe por parametro as Strings "cpf", "nome", "cpfConta" e "nomeConta" e chama os seus respectivos setters, para fazer o tratamento caso ocorra um erro. Além disso, verifica se os valores de cpf e nome correspondem com cpfConta e nomeConta.
     * @author Lucas Barros Gouveia.
     * @param cpf é o cpf passado por parametro.
     * @param nome é o nome passado por parametro.
     * @param cpfConta é o cpf de um objeto <strong>"Usuario"</strong> já criado.
     * @param nomeConta é o nome de um objeto <strong>"Usuario"</strong> já criado.
     */
    public void logar(String cpf, String nome, String cpfConta, String nomeConta) {
        try {
            if (cpfConta.equals(cpf) && nomeConta.equals(nome)) {
                setCpf(cpf);
                setNome(nome);
            } else {
                throw new Exception("Credenciais incorretas");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
