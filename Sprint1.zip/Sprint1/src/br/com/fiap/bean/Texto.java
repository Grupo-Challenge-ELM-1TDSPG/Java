package br.com.fiap.bean;

import java.time.LocalTime;

/**
 * Classe para criar objetos do tipo <strong>Texto</strong> que herdam a classe <strong>Tutorial</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Texto extends Tutorial{
    //atributos
    private int codText;
    private String conteudo;

    //construtores
    public Texto() {}
    public Texto(int codTuto, String titulo, int codText, String conteudo) {
        super(codTuto,titulo);
        this.codText = codText;
        this.conteudo = conteudo;
    }

    //getters / setters

    //codText
    public int getCodText() {
        return codText;
    }
    public void setCodText(int codText) {
        this.codText = codText;
    }

    //conteudo
    public String getConteudo() {
        return conteudo;
    }
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    //metodos
}
