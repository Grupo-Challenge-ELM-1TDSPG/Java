package br.com.fiap.bean;

/**
 * Classe para criar objetos do tipo <strong>ProfSaud</strong> que herdam a classe <strong>Usuario</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class ProfSaud extends Usuario {
    //atributos
    private int codSaud;
    private String senha;

    //construtores
    public ProfSaud() {}
    public ProfSaud(int codSaud, String cpf, String nome, String senha) {
        super(cpf, nome);
        this.codSaud = codSaud;
        setSenha(senha);
    }
    //getters / setters

    //codSaud
    public int getCodSaud() {
        return codSaud;
    }
    public void setCodSaud(int codSaud) {
        this.codSaud = codSaud;
    }

    //senha
    public String getSenha() {
        return senha;
    }

    /**
     * O setter "setSenha", recebe uma string por parametro que deve possuir entre 9 a 14 caracteres, caso contrário ele faz o tratamento de erro.
     * @author Lucas Barros Gouveia
     * @param senha é a senha passada por parametro.
     */
    public void setSenha(String senha) {
        try {
            if (senha.matches("^.{9,14}$")) {
                this.senha = senha;
            } else {
                throw new Exception("Senha incorreta! Deve possuir 9 a 14.");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //metodos
    /**
     * O metodo registrar sobrecarrega o metodo registrar da classe <strong>Usuario</strong>, adicionando também a String "senha" e chama seu setter, para fazer o tratamento caso ocorra um erro.
     * @author Lucas Barros Gouveia.
     * @param cpf é o cpf passado por parametro.
     * @param nome é o nome passado por parametro.
     * @param senha é a senha passada por parametro
     */
    public void registrar(String cpf, String nome, String senha) {
        super.registrar(cpf, nome);
        setSenha(senha);
    }

    /**
     * O metodo logar sobrecarrega o metodo logar da classe <strong>Usuario</strong>, adicionando também a String "senha" e "senhaConta" e chama os seus respectivos setters, para fazer o tratamento caso ocorra um erro. Além disso, verifica se os valores de cpf, nome e senha correspondem com cpfConta, nomeConta e senhaConta.
     * @author Lucas Barros Gouveia.
     * @param cpf é o cpf passado por parametro.
     * @param nome é o nome passado por parametro.
     * @param senha é o senha passada por parametro.
     * @param cpfConta é o cpf de um objeto <strong>"Usuario"</strong> já criado.
     * @param nomeConta é o nome de um objeto <strong>"Usuario"</strong> já criado.
     * @param senhaConta é o senha de um objeto <strong>"Usuario"</strong> já criado.
     */
    public void logar(String cpf, String nome, String senha, String cpfConta, String nomeConta, String senhaConta) {
        try {
            if (cpfConta.equals(cpf) && nomeConta.equals(nome) && senhaConta.equals(senha)) {
                setCpf(cpf);
                setNome(nome);
                setSenha(senha);
            } else {
                throw new Exception("Credenciais incorretas");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}