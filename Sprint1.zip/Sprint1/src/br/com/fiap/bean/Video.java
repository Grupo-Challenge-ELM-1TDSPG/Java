package br.com.fiap.bean;

import javax.print.attribute.standard.Media;
import java.time.LocalTime;

/**
 * Classe para criar objetos do tipo <strong>Video</strong> que herdam a classe <strong>Tutorial</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Video extends Tutorial{
    //atributos
    private int codVideo;
    private int volume;
    private LocalTime tempVideo;
    private LocalTime tempAtual;

    //construtores

    public Video() {}
    public Video(int codTuto, String titulo, int codVideo, int volume, LocalTime tempVideo, LocalTime tempAtual) {
        super(codTuto, titulo);
        this.codVideo = codVideo;
        this.volume = volume;
        this.tempVideo = tempVideo;
        this.tempAtual = tempAtual;
    }

    //getters / setters

    //codVideo
    public int getCodVideo() {
        return codVideo;
    }
    public void setCodVideo(int codVideo) {
        this.codVideo = codVideo;
    }

    //volume
    public int getVolume() {
        return volume;
    }
    public void setVolume(int volume) {
        this.volume = volume;
    }

    //tempVideo
    public LocalTime gettempVideo() {
        return tempVideo;
    }
    public void settempVideo(LocalTime tempVideo) {
        this.tempVideo = tempVideo;
    }

    //tempAtual
    public LocalTime getTempAtual() {
        return tempAtual;
    }
    public void setTempAtual(LocalTime tempAtual) {
        this.tempAtual = tempAtual;
    }

    //metodos
    /**
     * O metodo mudarVolume recebe um valor por parametro, que se for menor que 0, retorna 0, se for maior que 100, retorna 100. Caso seja entre 0 e 100, retorna esse valor
     * @param valor passa o valor do volume
     * @return int - retorna valor como volume.
     */
    public int mudarVolume(int valor) {
        if (valor >= 0 && valor <= 100) {
            return valor;
        } else {
            return volume;
        }
    }
    /**
     * O metodo mudarTemp recebe um tempo por parametro, que se for menor que o inicio do vídeo, retorna inicio do vídeo, se for maior que fim do vídeo, retorna o fim do vídeo. Caso seja no meio do vídeo, retorna o tempo selecionado.
     * @param temp é o tempo do vídeo passado por parametro
     * @return LocalTime - retorna o tempo do vídeo.
     */
    public LocalTime mudarTemp(LocalTime temp) {
        if (LocalTime.of(0,0).isBefore(temp) && tempVideo.isAfter(temp)) {
            return temp;
        } else if (temp.isBefore(LocalTime.of(0,0))){
            return LocalTime.of(0,0);
        } else if (temp.isAfter(tempVideo)){
            return tempVideo;
        } else {
            return tempAtual;
        }
    }
}
