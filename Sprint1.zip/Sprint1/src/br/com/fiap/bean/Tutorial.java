package br.com.fiap.bean;

import java.time.LocalTime;

/**
 * Classe para criar objetos do tipo <strong>Tutorial</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Tutorial {
    //atributos
    private int codTuto;
    private String titulo;

    //construtores
    public Tutorial() {
    }
    public Tutorial(int codTuto, String titulo) {
        this.codTuto = codTuto;
        this.titulo = titulo;
    }

    //getters / setters

    //codTuto
    public int getCodTuto() {
        return codTuto;
    }
    public void setCodTuto(int codTuto) {
        this.codTuto = codTuto;
    }

    //titulo
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
