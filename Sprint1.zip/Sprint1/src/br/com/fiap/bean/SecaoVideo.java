package br.com.fiap.bean;

import java.time.LocalTime;

/**
 * Classe para criar objetos do tipo <strong>SecaoVideo</strong> que herdam a classe <strong>Video</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class SecaoVideo extends Video{
    //atributos
    private int codSecao;
    private LocalTime ini;
    private LocalTime fim;

    //construtores
    public SecaoVideo() {}
    public SecaoVideo(int codTuto, String titulo, int codVideo, int volume, LocalTime tempVideo, LocalTime tempAtual, int codSecao, LocalTime ini, LocalTime fim) {
        super(codTuto, titulo, codVideo, volume, tempVideo, tempAtual);
        this.codSecao = codSecao;
        this.ini = ini;
        this.fim = fim;
    }

    // getters / setters

    //codSecao
    public int getCodSecao() {
        return codSecao;
    }
    public void setCodSecao(int codSecao) {
        this.codSecao = codSecao;
    }

    //ini
    public LocalTime getIni() {
        return ini;
    }
    public void setIni(LocalTime ini) {
        this.ini = ini;
    }

    //fim
    public LocalTime getFim() {
        return fim;
    }
    public void setFim(LocalTime fim) {
        this.fim = fim;
    }

    //metodos
    public LocalTime irSecao(LocalTime ini) {
        return ini;
    }
}
