package br.com.fiap.bean;

public class Receita {
    // atributos
    private int codRecei;
    private Paciente paci;
    private ProfSaud saud;
    private long contato;
    private String prescricao;

    // construtores
    public Receita() {}
    public Receita(int codRecei, Paciente paci, ProfSaud saud, long contato, String prescricao) {
        this.codRecei = codRecei;
        this.paci = paci;
        this.saud = saud;
        this.contato = contato;
        this.prescricao = prescricao;
    }

    // getters/setters

    // codRecei
    public int getCodRecei() {
        return codRecei;
    }
    public void setCodRecei(int codRecei) {
        this.codRecei = codRecei;
    }

    // paci
    public Paciente getPaci() {
        return paci;
    }
    public void setPaci(Paciente paci) {
        this.paci = paci;
    }

    // saud
    public ProfSaud getSaud() {
        return saud;
    }
    public void setSaud(ProfSaud saud) {
        this.saud = saud;
    }

    // contato
    public long getContato() {
        return contato;
    }
    public void setContato(long contato) {
        this.contato = contato;
    }

    // prescricao
    public String getPrescricao() {
        return prescricao;
    }
    public void setPrescricao(String prescricao) {
        this.prescricao = prescricao;
    }

    //metodos
    public String mostrarReceita() {
        return "Paciente: " + paci.getNome() + "\n" + "Contato: " + contato + "\nPrescrição" + prescricao + "\n\n" + saud.getNome();
    }
}
