package br.com.fiap.bean;

import java.time.LocalDateTime;

public class Consulta {
    //atributos
    private int codCons;
    private Paciente paci;
    private ProfSaud saud;
    private LocalDateTime data;

    //construtores
    public Consulta() {}
    public Consulta(int codCons, Paciente paci, ProfSaud saud, LocalDateTime data) {
        this.codCons = codCons;
        this.paci = paci;
        this.saud = saud;
        setData(data);
    }

    // getters/setters

    //codCons
    public int getCodCons() {
        return codCons;
    }
    public void setCodCons(int codCons) {
        this.codCons = codCons;
    }

    //paci
    public Paciente getPaci() {
        return paci;
    }
    public void setPaci(Paciente paci) {
        this.paci = paci;
    }

    //saud
    public ProfSaud getSaud() {
        return saud;
    }
    public void setSaud(ProfSaud saud) {
        this.saud = saud;
    }

    //data
    public LocalDateTime getData() {
        return data;
    }
    public void setData(LocalDateTime data) {
        try {
            if (data.isAfter(LocalDateTime.now())) {
                this.data = data;
            } else {
                throw new Exception("Horário inválido!");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //metodos
    public String solicitarConsulta() {
        return "Solicitação de consulta.\n\nPaciente: " + paci.getNome() + "\nProfissional da saúde: " + saud.getNome() + "\nData: " + data.getDayOfMonth() + "/" + data.getMonthValue() + "/" + data.getYear() + "\nHorário: " + data.getHour() + ":" + data.getMinute();
    }
    public String confirmarConsulta() {
        return "Consulta agendada.\n\nPaciente: " + paci.getNome() + "\nProfissional da saúde: " + saud.getNome() + "\nData: " + data.getDayOfMonth() + "/" + data.getMonthValue() + "/" + data.getYear() + "\nHorário: " + data.getHour() + ":" + data.getMinute();
    }
}
