package br.com.fiap.bean;

import java.time.LocalTime;

/**
 * Classe para criar objetos do tipo <strong>SecaoTexto</strong> que herdam a classe <strong>Texto</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class SecaoTexto extends Texto {
    //atributos
    private int codSecao;
    private String text;

    //construtores
    public SecaoTexto() {
    }

    public SecaoTexto(int codTuto, String titulo, int codText, String conteudo, int codSecao, String text) {
        super(codTuto, titulo, codText, conteudo);
        this.codSecao = codSecao;
        this.text = text;
    }

    // getters / setters

    //codSecao
    public int getCodSecao() {
        return codSecao;
    }

    public void setCodSecao(int codSecao) {
        this.codSecao = codSecao;
    }

    //text
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    //metodos

    /**
     * O metodo destacar pega uma seção do texto e coloca em upper case
     * @param indice passa o indice usado para selecionar os textos de acordo com o fluxo de condicionais.
     */
    public String mostrar(int indice) {
        try {
            if (indice == 1) {
                return "Para fazer Cadastro no Portal do Paciente HC, na página inicial do aplicativo HC, clique em 'CADASTRAR SENHA', na tela seguinte digite o número do CPF (Cadastro de pessoa física) do paciente.\n\n";
            } else if (indice == 2) {
                return "Depois, clique em 'LOCALIZAR PACIENTE'. O sistema vai procurar seu registro.";
            } else if (indice == 3) {
                return "Para fazer o login no Portal do Paciente HC, é preciso que já tenha feito o seu cadastro, criando uma senha de acesso.\n\n";
            } else if (indice == 4) {
                return "Na tela de login, digite o número de CPF do paciente (apenas os números) e senha nos campos correspondentes.";
            } else if (indice == 5) {
                return "Para encontrar sua teleconsulta, clique no ícone Menu do aplicativo pela opção 'Teleconsulta'. Geralmente, o ícone de Menu ☰ fica na parte de baixo e é com três listras na horizontal.\n\n";
            } else if (indice == 6) {
                return "Ao clicar em 'Teleconsulta', você deverá ver o seu agendamento listado. Por favor, toque sobre o nome do seu agendamento para continuar.";
            } else if (indice == 7) {
                return "Para visualizar os resultados dos seus exames vá na tela principal do Portal do Paciente HC, vá para Menu ☰\n\n";
            } else if (indice == 8) {
                return "Procure pela opção como 'Meus Resultados'. Ao clicar nessa opção, o aplicativo deve mostrar a lista dos seus exames que já têm resultados disponíveis para consulta.";
            } else {
                throw new Exception("Insira um tutorial válido!");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * O metodo esconder pega uma seção do texto e a esconde
     * @param text passa o texto selecionado
     */
    public void esconder(String text) {
        text = text.replace(text, "");
    }
}
