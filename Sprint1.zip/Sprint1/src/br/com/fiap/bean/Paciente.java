package br.com.fiap.bean;

/**
 * Classe para criar objetos do tipo <strong>Paciente</strong> que herdam a classe <strong>Usuario</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Paciente extends Usuario {
    //atributos
    private int codPaci;

    //construtores
    public Paciente() {}

    public Paciente(int codPaci, String cpf, String nome) {
        super(cpf, nome);
        this.codPaci = codPaci;
    }

    //getters / setters

    //codPaci
    public int getCodPaci() {
        return codPaci;
    }
    public void setCodPaci(int codPaci) {
        this.codPaci = codPaci;
    }
}
