package br.com.fiap.bean;

/**
 * Classe para criar objetos do tipo <strong>Chatbot</strong>
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Chatbot {
    //atributos
    private int codBot;
    private Paciente pergFreq;
    private Paciente codPaci;

    //construtores
    public Chatbot() {}
    public Chatbot(int codBot, Paciente pergFreq, Paciente codPaci) {
        this.codBot = codBot;
        this.pergFreq = pergFreq;
        this.codPaci = codPaci;
    }

    //getters / setters

    //codBot
    public int getCodBot() {
        return codBot;
    }
    public void setCodBot(int codBot) {
        this.codBot = codBot;
    }

    //pergFreq
    public Paciente getPergFreq() {
        return pergFreq;
    }
    public void setPergFreq(Paciente pergFreq) {
        this.pergFreq = pergFreq;
    }

    //codPaci
    public Paciente getCodPaci() {
        return codPaci;
    }
    public void setCodPaci(Paciente codPaci) {
        this.codPaci = codPaci;
    }

    //metodos

    /**
     * Metodo perguntar permite o usuário fazer uma pergunta que é passada por parametro e retorna uma resposta.
     * @author Lucas Barros Gouveia
     * @param perg é a pergunta do usuário
     * @return String - retorna a resposta.;
     */
    public String perguntar(String perg) {
        if (perg.equalsIgnoreCase("Como entro na teleconsulta?") || perg.equalsIgnoreCase("Teleconsulta")) {
            return "Para encontrar sua teleconsulta, clique no ícone Menu do aplicativo pela opção 'Teleconsulta'. Geralmente, o ícone de Menu ☰ fica na parte de baixo e é com três listras na horizontal.\n\nAo clicar em 'Teleconsulta', você deverá ver o seu agendamento listado. Por favor, toque sobre o nome do seu agendamento para continuar.";
        } else if (perg.equalsIgnoreCase("Como vejo os exames?") || perg.equalsIgnoreCase("Exame"))  {
            return "Para visualizar os resultados dos seus exames vá na tela principal do Portal do Paciente HC, vá para Menu ☰\n\nProcure pela opção como 'Meus Resultados'. Ao clicar nessa opção, o aplicativo deve mostrar a lista dos seus exames que já têm resultados disponíveis para consulta.";
        } else if (perg.equalsIgnoreCase("Como faço cadastro?") || perg.equalsIgnoreCase("Cadastro"))  {
            return "Para fazer Cadastro no Portal do Paciente HC, na página inicial do aplicativo HC, clique em 'CADASTRAR SENHA', na tela seguinte digite o número do CPF (Cadastro de pessoa física) do paciente.\n\nDepois, clique em 'LOCALIZAR PACIENTE'. O sistema vai procurar seu registro.";
        } else if (perg.equalsIgnoreCase("Como faço login?") || perg.equalsIgnoreCase("Login")) {
                return "Para fazer o login no Portal do Paciente HC, é preciso que já tenha feito o seu cadastro, criando uma senha de acesso.\n\nNa tela de login, digite o número de CPF do paciente (apenas os números) e senha nos campos correspondentes.";
        } else
        {
            return "Não reconheci sua pergunta.";
        }
    }
}
