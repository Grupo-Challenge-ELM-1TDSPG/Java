package br.com.fiap.main;

import br.com.fiap.bean.*;

import javax.swing.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe Main, onde é feito a solução principal
 * @author Lucas Barros Gouveia
 * @version 1.0
 * @since 21.0.7
 */
public class Main {
    public static void main(String[] args) {
        int conta = 0, i = 1, iBot = 1, iCons = 1, serv, tipo;
        List<String> consults = new ArrayList<>();
        Paciente paciAtual;
        ProfSaud saudAtual;
        Consulta cons = new Consulta();
        Receita rec = new Receita(0, null, null, 0, "");
        Paciente paci = new Paciente(0, "00000000000", "a");
        ProfSaud saud = new ProfSaud(0, "00000000000", "a", "aaaaaaaaa");
        Texto text;
        Video video;
        Chatbot bot;

        while (conta != 3) {
            try {
                // Escolhe entre cadastro e login
                conta = Integer.parseInt(JOptionPane.showInputDialog("Boas vindas.\n1 - Cadastrar\n2 - Logar\n3 - Sair"));
                switch (conta) {
                    case 1:
                        // Escolhe o tipo de conta
                        conta = Integer.parseInt(JOptionPane.showInputDialog("Cadastrar que tipo de conta?\n1 - Profissional da saúde\n2 - Paciente\n3 - Sair"));
                        switch (conta) {
                            case 1:
                                //Profissional da saude
                                saudAtual = new ProfSaud();
                                saudAtual.setCodSaud(i);
                                saudAtual.registrar(JOptionPane.showInputDialog("Digite o cpf."), JOptionPane.showInputDialog("Digite o seu nome."), JOptionPane.showInputDialog("Digite uma senha."));
                                saud = new ProfSaud(i, saudAtual.getCpf(), saudAtual.getNome(), saudAtual.getSenha());
                                i++;

                                serv = 0;
                                while (serv != 5) {
                                    try {
                                        // Escolhe o serviço
                                        serv = Integer.parseInt(JOptionPane.showInputDialog("Qual serviço você gostaria?\n1 - Tutorial\n2 - Chatbot\n3 - Consultas\n4 - Prescrever receita\n5 - Sair da conta"));
                                        switch (serv) {
                                            case 1:
                                                // Escolhe o tipo do tutorial
                                                tipo = Integer.parseInt(JOptionPane.showInputDialog("Qual tipo tutorial?\n1 - Texto\n2 - Vídeo\n3 - Voltar"));
                                                do {
                                                    try {
                                                        switch (tipo) {
                                                            case 1:
                                                                text = new Texto();

                                                                // Escolhe o tutorial
                                                                text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                switch (text.getCodTuto()) {
                                                                    case 1:
                                                                        SecaoTexto cad1 = new SecaoTexto();
                                                                        SecaoTexto cad2 = new SecaoTexto();
                                                                        text.setTitulo("Cadastro");
                                                                        text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 2:
                                                                        SecaoTexto log1 = new SecaoTexto();
                                                                        SecaoTexto log2 = new SecaoTexto();
                                                                        text.setTitulo("Login");
                                                                        text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 3:
                                                                        SecaoTexto tele1 = new SecaoTexto();
                                                                        SecaoTexto tele2 = new SecaoTexto();
                                                                        text.setTitulo("Teleconsulta");
                                                                        text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 4:
                                                                        SecaoTexto exam1 = new SecaoTexto();
                                                                        SecaoTexto exam2 = new SecaoTexto();
                                                                        text.setTitulo("Exame");
                                                                        text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 5:
                                                                        tipo = 3;
                                                                        break;
                                                                }
                                                                break;
                                                            case 2:
                                                                video = new Video();
                                                                text = new Texto();

                                                                // Escolhe o tutorial
                                                                text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                switch (text.getCodTuto()) {
                                                                    case 1:
                                                                        SecaoTexto cad1 = new SecaoTexto();
                                                                        SecaoTexto cad2 = new SecaoTexto();
                                                                        text.setTitulo("Cadastro");
                                                                        text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 2:
                                                                        SecaoTexto log1 = new SecaoTexto();
                                                                        SecaoTexto log2 = new SecaoTexto();
                                                                        text.setTitulo("Login");
                                                                        text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 3:
                                                                        SecaoTexto tele1 = new SecaoTexto();
                                                                        SecaoTexto tele2 = new SecaoTexto();
                                                                        text.setTitulo("Teleconsulta");
                                                                        text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 4:
                                                                        SecaoTexto exam1 = new SecaoTexto();
                                                                        SecaoTexto exam2 = new SecaoTexto();
                                                                        text.setTitulo("Exame");
                                                                        text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 5:
                                                                        tipo = 3;
                                                                        break;
                                                                }
                                                                break;
                                                            default:
                                                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                                break;
                                                        }
                                                    } catch (Exception e) {
                                                        JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                                    }
                                                } while (JOptionPane.showConfirmDialog(null, "Deseja ver outro tutorial?", "Tutorial", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                break;
                                            case 2:
                                                bot = new Chatbot();
                                                bot.setCodBot(iBot);

                                                do {
                                                    JOptionPane.showMessageDialog(null, bot.perguntar(JOptionPane.showInputDialog("Digite uma pergunta.")));
                                                } while (JOptionPane.showConfirmDialog(null, "Deseja fazer outra pergunta?", "Chatbot", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                break;
                                            case 3:
                                                int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o serviço\n1 - Ver consultas\n2 - Ver solicitações de consultas\n3 - voltar"));
                                                switch (choice) {
                                                    case 1:
                                                        if (consults.isEmpty()) {
                                                            JOptionPane.showMessageDialog(null, "Você não possui consultas agendadas no momento", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                        } else {
                                                            JOptionPane.showMessageDialog(null, consults.toString(), "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                        }
                                                        break;
                                                    case 2:
                                                        if (cons.getCodCons() != 0) {
                                                            if (JOptionPane.showConfirmDialog(null, "Aceitar solicitação de consulta?:\n" + cons.solicitarConsulta(), "Consulta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0) {
                                                                cons.setCodCons(iCons);
                                                                consults.add(cons.confirmarConsulta());
                                                            } else {
                                                                JOptionPane.showMessageDialog(null, "Consulta rejeitada.", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                            }
                                                        } else {
                                                            JOptionPane.showMessageDialog(null, "Não há consultas solicitadas.", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                        }
                                                        break;
                                                    case 3:
                                                        break;
                                                    default:
                                                        JOptionPane.showMessageDialog(null, "Valor inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
                                                        break;
                                                }
                                                break;
                                            case 4:
                                                JOptionPane.showMessageDialog(null, rec);
                                                break;
                                            case 5:
                                                JOptionPane.showMessageDialog(null, "Saindo da conta...");
                                                break;
                                            default:
                                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                break;
                                        }
                                    } catch (Exception e) {
                                        JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            case 2:
                                paciAtual = new Paciente();
                                paciAtual.setCodPaci(i);
                                paciAtual.registrar(JOptionPane.showInputDialog("Digite seu cpf"), JOptionPane.showInputDialog("Digite seu nome"));
                                paci = new Paciente(paciAtual.getCodPaci(), paciAtual.getCpf(), paciAtual.getNome());
                                i++;

                                serv = 0;
                                while (serv != 5) {
                                    try {
                                        // Escolhe o serviço
                                        serv = Integer.parseInt(JOptionPane.showInputDialog("Qual serviço você gostaria?\n1 - Tutorial\n2 - Chatbot\n3 - Consulta\n4 - Ver receitas\n5 - Sair"));
                                        switch (serv) {
                                            case 1:
                                                // Escolhe o tipo do tutorial
                                                tipo = Integer.parseInt(JOptionPane.showInputDialog("Qual tipo tutorial?\n1 - Texto\n2 - Vídeo\n3 - Voltar"));
                                                do {
                                                    try {
                                                        switch (tipo) {
                                                            case 1:
                                                                text = new Texto();

                                                                // Escolhe o tutorial
                                                                text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                switch (text.getCodTuto()) {
                                                                    case 1:
                                                                        SecaoTexto cad1 = new SecaoTexto();
                                                                        SecaoTexto cad2 = new SecaoTexto();
                                                                        text.setTitulo("Cadastro");
                                                                        text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 2:
                                                                        SecaoTexto log1 = new SecaoTexto();
                                                                        SecaoTexto log2 = new SecaoTexto();
                                                                        text.setTitulo("Login");
                                                                        text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 3:
                                                                        SecaoTexto tele1 = new SecaoTexto();
                                                                        SecaoTexto tele2 = new SecaoTexto();
                                                                        text.setTitulo("Teleconsulta");
                                                                        text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 4:
                                                                        SecaoTexto exam1 = new SecaoTexto();
                                                                        SecaoTexto exam2 = new SecaoTexto();
                                                                        text.setTitulo("Exame");
                                                                        text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 5:
                                                                        tipo = 3;
                                                                        break;
                                                                }

                                                                break;
                                                            case 2:
                                                                video = new Video();
                                                                text = new Texto();

                                                                // Escolhe o tutorial
                                                                text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                switch (text.getCodTuto()) {
                                                                    case 1:
                                                                        SecaoTexto cad1 = new SecaoTexto();
                                                                        SecaoTexto cad2 = new SecaoTexto();
                                                                        text.setTitulo("Cadastro");
                                                                        text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 2:
                                                                        SecaoTexto log1 = new SecaoTexto();
                                                                        SecaoTexto log2 = new SecaoTexto();
                                                                        text.setTitulo("Login");
                                                                        text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 3:
                                                                        SecaoTexto tele1 = new SecaoTexto();
                                                                        SecaoTexto tele2 = new SecaoTexto();
                                                                        text.setTitulo("Teleconsulta");
                                                                        text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 4:
                                                                        SecaoTexto exam1 = new SecaoTexto();
                                                                        SecaoTexto exam2 = new SecaoTexto();
                                                                        text.setTitulo("Exame");
                                                                        text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                        JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                        break;
                                                                    case 5:
                                                                        tipo = 3;
                                                                        break;
                                                                }
                                                                break;
                                                            default:
                                                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                                break;
                                                        }
                                                    } catch (Exception e) {
                                                        JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                                    }
                                                } while (JOptionPane.showConfirmDialog(null, "Deseja ver outro tutorial?", "Tutorial", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                break;
                                            case 2:
                                                bot = new Chatbot();
                                                bot.setCodBot(i);

                                                do {
                                                    JOptionPane.showMessageDialog(null, bot.perguntar(JOptionPane.showInputDialog("Digite uma pergunta.")));
                                                } while (JOptionPane.showConfirmDialog(null, "Deseja fazer outra pergunta?", "Chatbot", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                break;
                                            case 3:
                                                int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o serviço\n1 - Ver consultas\n2 - Solicitar consultas\n3 - voltar"));
                                                switch (choice) {
                                                    case 1:
                                                        if (consults.isEmpty()) {
                                                            JOptionPane.showMessageDialog(null, "Você não possui consultas agendadas no momento", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                        } else {
                                                            JOptionPane.showMessageDialog(null, consults.toString(), "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                        }
                                                        break;
                                                    case 2:
                                                        if (saud.getCodSaud() != 0) {
                                                            cons = new Consulta();
                                                            String dia = JOptionPane.showInputDialog(null, "Digite a data da consulta. (dd/mm/aaaa)", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                            String hora = JOptionPane.showInputDialog(null, "Digite o horário da consulta. (hh:mm)", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                            String dataHora = dia.substring(6, 10) + "-" + dia.substring(3, 5) + "-" + dia.substring(0, 2) + "T" + hora + ":00";
                                                            cons.setCodCons(iCons);
                                                            cons.setSaud(saud);
                                                            cons.setPaci(paci);
                                                            cons.setData(LocalDateTime.parse(dataHora));
                                                            if (JOptionPane.showConfirmDialog(null, "Confirmar consulta?\n\n" + cons.solicitarConsulta(), "Consulta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 1) {
                                                                cons.setCodCons(0);
                                                                cons.setPaci(null);
                                                                cons.setSaud(null);
                                                            }
                                                        } else {
                                                            JOptionPane.showMessageDialog(null, "Não há profissionais da saúde disponiveis no momento.", "Consulta", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        break;
                                                    case 3:
                                                        break;
                                                    default:
                                                        JOptionPane.showMessageDialog(null, "Valor inválido", "Erro", JOptionPane.ERROR_MESSAGE);
                                                        break;
                                                }
                                                break;
                                            case 4:
                                                break;
                                            case 5:
                                                JOptionPane.showMessageDialog(null, "Saindo da conta...");
                                                break;
                                            default:
                                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                break;
                                        }
                                    } catch (Exception e) {
                                        JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                    }
                                }
                                break;
                            case 3:
                                JOptionPane.showMessageDialog(null, "Adeus...");
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                break;
                        }
                        break;
                    case 2:
                        // Escolhe o tipo de conta
                        conta = Integer.parseInt(JOptionPane.showInputDialog("Logar em que tipo de conta?\n1 - Profissional da saúde\n2 - Paciente\n3 - Sair"));
                        switch (conta) {
                            case 1:
                                if (saud.getCodSaud() == 0 || saud.getCpf().equals("00000000000") || saud.getNome().equals("a") || saud.getSenha().equals("aaaaaaaaa")) {
                                    JOptionPane.showMessageDialog(null, "Ainda não existe uma conta cadastrada.");
                                    break;
                                } else {
                                    saudAtual = new ProfSaud();
                                    saudAtual.logar(JOptionPane.showInputDialog("Digite o cpf."), JOptionPane.showInputDialog("Digite o seu nome."), JOptionPane.showInputDialog("Digite a sua senha."), saud.getCpf(), saud.getNome(), saud.getSenha());

                                    if (saud.getCpf().equals(saudAtual.getCpf()) && saud.getNome().equals(saudAtual.getNome()) && saud.getSenha().equals(saudAtual.getSenha())) {
                                        saudAtual.setCodSaud(saud.getCodSaud());
                                        JOptionPane.showMessageDialog(null, "Login realizado.");
                                        serv = 0;

                                        while (serv != 5) {
                                            try {
                                                // Escolhe o serviço
                                                serv = Integer.parseInt(JOptionPane.showInputDialog("Qual serviço você gostaria?\n1 - Tutorial\n2 - Chatbot\n3 - Consulta\n4 - Prescrever receita\n5 - Sair da conta"));
                                                switch (serv) {
                                                    case 1:
                                                        // Escolhe o tipo do tutorial
                                                        tipo = Integer.parseInt(JOptionPane.showInputDialog("Qual tipo tutorial?\n1 - Texto\n2 - Vídeo\n3 - Voltar"));
                                                        do {
                                                            try {
                                                                switch (tipo) {
                                                                    case 1:
                                                                        text = new Texto();

                                                                        // Escolhe o tutorial
                                                                        text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                        switch (text.getCodTuto()) {
                                                                            case 1:
                                                                                SecaoTexto cad1 = new SecaoTexto();
                                                                                SecaoTexto cad2 = new SecaoTexto();
                                                                                text.setTitulo("Cadastro");
                                                                                text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 2:
                                                                                SecaoTexto log1 = new SecaoTexto();
                                                                                SecaoTexto log2 = new SecaoTexto();
                                                                                text.setTitulo("Login");
                                                                                text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 3:
                                                                                SecaoTexto tele1 = new SecaoTexto();
                                                                                SecaoTexto tele2 = new SecaoTexto();
                                                                                text.setTitulo("Teleconsulta");
                                                                                text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 4:
                                                                                SecaoTexto exam1 = new SecaoTexto();
                                                                                SecaoTexto exam2 = new SecaoTexto();
                                                                                text.setTitulo("Exame");
                                                                                text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 5:
                                                                                tipo = 3;
                                                                                break;
                                                                        }
                                                                        break;
                                                                    case 2:
                                                                        video = new Video();
                                                                        text = new Texto();

                                                                        // Escolhe o tutorial
                                                                        text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                        switch (text.getCodTuto()) {
                                                                            case 1:
                                                                                SecaoTexto cad1 = new SecaoTexto();
                                                                                SecaoTexto cad2 = new SecaoTexto();
                                                                                text.setTitulo("Cadastro");
                                                                                text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 2:
                                                                                SecaoTexto log1 = new SecaoTexto();
                                                                                SecaoTexto log2 = new SecaoTexto();
                                                                                text.setTitulo("Login");
                                                                                text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 3:
                                                                                SecaoTexto tele1 = new SecaoTexto();
                                                                                SecaoTexto tele2 = new SecaoTexto();
                                                                                text.setTitulo("Teleconsulta");
                                                                                text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 4:
                                                                                SecaoTexto exam1 = new SecaoTexto();
                                                                                SecaoTexto exam2 = new SecaoTexto();
                                                                                text.setTitulo("Exame");
                                                                                text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 5:
                                                                                tipo = 3;
                                                                                break;
                                                                        }
                                                                        break;
                                                                    default:
                                                                        JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                                        break;
                                                                }
                                                            } catch (Exception e) {
                                                                JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                                            }
                                                        } while (JOptionPane.showConfirmDialog(null, "Deseja ver outro tutorial?", "Tutorial", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                        break;
                                                    case 2:
                                                        bot = new Chatbot();
                                                        bot.setCodBot(iBot);

                                                        do {
                                                            JOptionPane.showMessageDialog(null, bot.perguntar(JOptionPane.showInputDialog("Digite uma pergunta.")));
                                                        } while (JOptionPane.showConfirmDialog(null, "Deseja fazer outra pergunta?", "Chatbot", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                        break;
                                                    case 3:
                                                        int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o serviço\n1 - Ver consultas\n2 - Ver solicitações de consultas\n3 - voltar"));
                                                        switch (choice) {
                                                            case 1:
                                                                if (consults.isEmpty()) {
                                                                    JOptionPane.showMessageDialog(null, "Você não possui consultas agendadas no momento", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                } else {
                                                                    JOptionPane.showMessageDialog(null, consults.toString(), "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                }
                                                                break;
                                                            case 2:
                                                                if (cons.getCodCons() != 0) {
                                                                    if (JOptionPane.showConfirmDialog(null, "Aceitar solicitação de consulta?:\n" + cons.solicitarConsulta(), "Consulta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0) {
                                                                        consults.add(cons.confirmarConsulta());
                                                                    } else {
                                                                        JOptionPane.showMessageDialog(null, "Consulta rejeitada.", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                    }
                                                                } else {
                                                                    JOptionPane.showMessageDialog(null, "Não há consultas solicitadas.", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                }
                                                                break;
                                                            case 3:
                                                                break;
                                                            default:
                                                                JOptionPane.showMessageDialog(null, "Valor inválido.", "Erro", JOptionPane.ERROR_MESSAGE);
                                                                break;
                                                        }
                                                        break;
                                                    case 4:
                                                        JOptionPane.showMessageDialog(null, rec);
                                                        break;
                                                    case 5:
                                                        JOptionPane.showMessageDialog(null, "Saindo da conta...");
                                                        break;
                                                    default:
                                                        JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                        break;
                                                }
                                            } catch (Exception e) {
                                                JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                            }
                                        }
                                    }
                                }
                            break;
                            case 2:
                                if (paci.getCodPaci() == 0 || paci.getCpf().equals("00000000000") || paci.getNome().equals("a")) {
                                    JOptionPane.showMessageDialog(null, "Ainda não existe uma conta cadastrada.");
                                    break;
                                } else {
                                    paciAtual = new Paciente();
                                    paciAtual.logar(JOptionPane.showInputDialog("Digite o cpf."), JOptionPane.showInputDialog("Digite o seu nome."), paci.getCpf(), paci.getNome());
                                    if (paci.getCpf().equals(paciAtual.getCpf()) && paci.getNome().equals(paciAtual.getNome())) {
                                        paciAtual.setCodPaci(paci.getCodPaci());
                                        JOptionPane.showMessageDialog(null, "Login realizado.");
                                        serv = 0;

                                        while (serv != 5) {
                                            try {
                                                // Escolhe o serviço
                                                serv = Integer.parseInt(JOptionPane.showInputDialog("Qual serviço você gostaria?\n1 - Tutorial\n2 - Chatbot\n3 - Consulta\n4 - Ver receitas\n5 - Sair"));
                                                switch (serv) {
                                                    case 1:
                                                        // Escolhe o tipo do tutorial
                                                        tipo = Integer.parseInt(JOptionPane.showInputDialog("Qual tipo tutorial?\n1 - Texto\n2 - Vídeo\n3 - Voltar"));
                                                        do {
                                                            try {
                                                                switch (tipo) {
                                                                    case 1:
                                                                        text = new Texto();

                                                                        // Escolhe o tutorial
                                                                        text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                        switch (text.getCodTuto()) {
                                                                            case 1:
                                                                                SecaoTexto cad1 = new SecaoTexto();
                                                                                SecaoTexto cad2 = new SecaoTexto();
                                                                                text.setTitulo("Cadastro");
                                                                                text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 2:
                                                                                SecaoTexto log1 = new SecaoTexto();
                                                                                SecaoTexto log2 = new SecaoTexto();
                                                                                text.setTitulo("Login");
                                                                                text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 3:
                                                                                SecaoTexto tele1 = new SecaoTexto();
                                                                                SecaoTexto tele2 = new SecaoTexto();
                                                                                text.setTitulo("Teleconsulta");
                                                                                text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 4:
                                                                                SecaoTexto exam1 = new SecaoTexto();
                                                                                SecaoTexto exam2 = new SecaoTexto();
                                                                                text.setTitulo("Exame");
                                                                                text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 5:
                                                                                tipo = 3;
                                                                                break;
                                                                        }

                                                                        break;
                                                                    case 2:
                                                                        video = new Video();
                                                                        text = new Texto();

                                                                        // Escolhe o tutorial
                                                                        text.setCodTuto(Integer.parseInt(JOptionPane.showInputDialog("Qual tutorial você gostaria?\n1 - Cadastro\n2 - Login\n3 - Teleconsulta\n4 - Exame\n5 - Sair dos tutoriais.")));
                                                                        switch (text.getCodTuto()) {
                                                                            case 1:
                                                                                SecaoTexto cad1 = new SecaoTexto();
                                                                                SecaoTexto cad2 = new SecaoTexto();
                                                                                text.setTitulo("Cadastro");
                                                                                text.setConteudo(cad1.mostrar(1) + cad2.mostrar(2));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 2:
                                                                                SecaoTexto log1 = new SecaoTexto();
                                                                                SecaoTexto log2 = new SecaoTexto();
                                                                                text.setTitulo("Login");
                                                                                text.setConteudo(log1.mostrar(3) + log2.mostrar(4));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 3:
                                                                                SecaoTexto tele1 = new SecaoTexto();
                                                                                SecaoTexto tele2 = new SecaoTexto();
                                                                                text.setTitulo("Teleconsulta");
                                                                                text.setConteudo(tele1.mostrar(5) + tele2.mostrar(6));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 4:
                                                                                SecaoTexto exam1 = new SecaoTexto();
                                                                                SecaoTexto exam2 = new SecaoTexto();
                                                                                text.setTitulo("Exame");
                                                                                text.setConteudo(exam1.mostrar(7) + exam2.mostrar(8));
                                                                                JOptionPane.showMessageDialog(null, text.getConteudo(), text.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
                                                                                break;
                                                                            case 5:
                                                                                tipo = 3;
                                                                                break;
                                                                        }
                                                                        break;
                                                                    default:
                                                                        JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                                        break;
                                                                }
                                                            } catch (Exception e) {
                                                                JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                                            }
                                                        } while (JOptionPane.showConfirmDialog(null, "Deseja ver outro tutorial?", "Tutorial", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                        break;
                                                    case 2:
                                                        bot = new Chatbot();
                                                        bot.setCodBot(i);

                                                        do {
                                                            JOptionPane.showMessageDialog(null, bot.perguntar(JOptionPane.showInputDialog("Digite uma pergunta.")));
                                                        } while (JOptionPane.showConfirmDialog(null, "Deseja fazer outra pergunta?", "Chatbot", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
                                                        break;
                                                    case 3:
                                                        int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o serviço\n1 - Ver consultas\n2 - Solicitar consultas\n3 - voltar"));
                                                        switch (choice) {
                                                            case 1:
                                                                if (consults.isEmpty()) {
                                                                    JOptionPane.showMessageDialog(null, "Você não possui consultas agendadas no momento", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                } else {
                                                                    JOptionPane.showMessageDialog(null, consults.toString(), "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                }
                                                                break;
                                                            case 2:
                                                                if (saud.getCodSaud() != 0) {
                                                                    cons = new Consulta();
                                                                    String dia = JOptionPane.showInputDialog(null, "Digite a data da consulta. (dd/mm/aaaa)", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                    String hora = JOptionPane.showInputDialog(null, "Digite o horário da consulta. (hh:mm)", "Consulta", JOptionPane.INFORMATION_MESSAGE);
                                                                    String dataHora = dia.substring(6, 10) + "-" + dia.substring(3, 5) + "-" + dia.substring(0, 2) + "T" + hora + ":00";
                                                                    cons.setCodCons(iCons);
                                                                    cons.setSaud(saud);
                                                                    cons.setPaci(paci);
                                                                    cons.setData(LocalDateTime.parse(dataHora));
                                                                    if (JOptionPane.showConfirmDialog(null, "Confirmar consulta?\n\n" + cons.solicitarConsulta(), "Consulta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 1) {
                                                                        cons.setCodCons(0);
                                                                        cons.setPaci(null);
                                                                        cons.setSaud(null);
                                                                        cons.setData(null);
                                                                    }
                                                                } else {
                                                                    JOptionPane.showMessageDialog(null, "Não há profissionais da saúde disponiveis no momento.", "Consulta", JOptionPane.WARNING_MESSAGE);
                                                                }
                                                                break;
                                                            case 3:
                                                                break;
                                                            default:
                                                                JOptionPane.showMessageDialog(null, "Valor inválido", "Erro", JOptionPane.ERROR_MESSAGE);
                                                                break;
                                                        }
                                                        break;
                                                    case 4:
                                                        break;
                                                    case 5:
                                                        JOptionPane.showMessageDialog(null, "Saindo da conta...");
                                                        break;
                                                    default:
                                                        JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                                        break;
                                                }
                                            } catch (Exception e) {
                                                JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                                            }
                                        }
                                    }
                                }
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Escolha inválida!");
                                break;
                        }
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Adeus...");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Escolha inválida!");
                        break;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
